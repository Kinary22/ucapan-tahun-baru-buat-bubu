
function revealSurprise() {
  const surprise = document.getElementById("surprise");
  surprise.classList.remove("hidden");
}
